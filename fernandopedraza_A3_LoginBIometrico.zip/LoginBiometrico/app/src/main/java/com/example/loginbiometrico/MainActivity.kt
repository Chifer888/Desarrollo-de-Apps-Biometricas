package com.example.loginbiometrico

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Encuentra el botón usando findViewById
        val button1 = findViewById<View>(R.id.button1)

        // Usar lifecycleScope para retrasar la aparición del botón
        lifecycleScope.launch {
            delay(3000) // Retraso de 3 segundos
            button1.visibility = View.VISIBLE
        }

        // Agrega un OnClickListener al botón para iniciar la nueva actividad
        button1.setOnClickListener {
            // Crea el Intent para iniciar MainActivity2
            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent) // Inicia la nueva actividad
        }
    }
}